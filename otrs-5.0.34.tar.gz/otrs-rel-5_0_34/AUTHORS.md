The following persons contributed to OTRS:

* 1soproni <csaba@sopron.hu>
* Alex Kantchev <ak@otrs.com>
* Alex Mazur <alex.mazur@otrs.com>
* Alexandre D. Rogoski <alexandre@exatati.com.br>
* Belnet <info@belnet.be>
* Bernhard Schmalhofer <bernhard.schmalhofer@otrs.com>
* Bodo Bauer <bodo.bauer@otrs.com>
* Burchard Steinbild <burchard.steinbild@otrs.com>
* Carlos Garcia <carlos.garcia@otrs.com>
* Carlos Rodriguez <carlos.rodriguez@otrs.com>
* Christian Schöpplein <christian.schoepplein@otrs.com>
* Christopher T. Kuhn <christopher.kuhn@otrs.com>
* Cyrille Bollu <info@belnet.be>
* Daniel Zamorano <daniel.zamorano@otrs.com>
* David Crimi <deathpoison.dc@gmail.com>
* Denis Nelubin <dnelubin@gmail.com>
* Dennis Schmelter <dennis.schmelter@otrs.com>
* Diego Selzlein <diegoselzlein@gmail.com>
* Dietmar Berg <dietmar.berg@thalesgroup.com>
* Dominik Klein <dominik.klein@otrs.com>
* Dusan Vuckovic <dusan.vuckovic@muehlbauer.de>
* Elias Probst <elias.probst@otrs.com>
* Elva Novoa <elva.novoa@otrs.com>
* Enrique Matías Sánchez (Quique) <cronopios@gmail.com>
* Felix Niklas <felix.niklas@otrs.com>
* Friedrich Delgado <friedel@nomaden.org>
* Gerald Young <gerald.young@noynim.com>
* Henning Oschwald <henning.oschwald@otrs.com>
* IB Development Team <dev@ib.pl>
* Jan Steinweg <jan.steinweg@otrs.com>
* Jens Bothe <jens.bothe@otrs.com>
* Jens Pfeifer <jens.pfeifer@otrs.com>
* Johannes Hörburger <johannes.hoerburger@otrs.com>
* Johannes Nickel <hanne_hal@me.com>
* Keith Moore <tenareth@gmail.com>
* Luca Maranzano <liuk@linux.it>
* Manuel Hecht <manuel.hecht@otrs.com>
* Marc Bonsels <marc.bonsels@otrs.com>
* Marc Nilius <marc.nilius@otrs.com>
* Marco Buchholz <marco.buchholz@otrs.com>
* Markus Esche <markus.esche@otrs.com>
* Martha Pascual <martha.pascual@otrs.com>
* Martin Edenhofer <martin.edenhofer@otrs.com>
* Martin Gross <martin@pc-coholic.de>
* Martin Gruner <martin.gruner@otrs.com>
* Mathias Bräunling <mathias.braeunling@otrs.com>
* Michael Tänzer <neo@nhng.de>
* Michiel Beijen <michiel.beijen@otrs.com>
* Moritz Lenz <mlenz@noris.net>
* NeverMin <never.min@gmail.com>
* Nils Leideck <nils.leideck@leidex.net>
* Nils Leideck <nils.leideck@otrs.com>
* Norihiro Tanaka <noritnk@kcn.ne.jp>
* Oberson Dylan <dylan.oberson@epfl.ch>
* Oliver Tappe <oliver.tappe@otrs.com>
* Olivier Sallou <olivier.sallou@irisa.fr>
* Patrick Brischler <patrick.brischler@otrs.com>
* Patrick Rauscher <prauscher@ohai.su>
* Paul Waring <paul@xk7.net>
* Peter Krantz <peter@peterkrantz.se>
* Ralf Hildebrandt <hildeb@charite.de>
* Raphaël Doursenaud <rdoursenaud@gpcsolutions.fr>
* Renée Bäcker <info@perl-services.de>
* Richard Kammermayer <richard.kammermayer@otrs.com>
* Rolf Schmidt <rolf.schmidt@otrs.com>
* Romain THERRAT <romain42@gmail.com>
* Shawn Beasley <shawn.beasley@otrs.com>
* Stefan Bedorf <stefan.bedorf@otrs.com>
* Stefan Rother <stefan.rother@otrs.com>
* Stefan Wintermeyer <stefan@otrs.org>
* Theo van Hoesel <Th.J.v.Hoesel+GitHub@gmail.com>
* Thomas Raith <thomas.raith@otrs.com>
* Thorsten Eckel <thorsten.eckel@otrs.com>
* Torsten Thau <Torsten.Thau@cape-it.de>
* Udo Bretz <udo.bretz@otrs.com>
* Uwe Dieckmann <uwe.dieckmann@otrs.com>
* Walter Souto <walter.souto@saude.go.gov.br>
* Wojciech Kuchta <klapi85@gmail.com>
* Wojciech Kuchta <wojciech.kuchta@allegro.pl>
* djurici <igor.djuric@muehlbauer.de>
* juanmclavero <juanm.clavero@ibsalut.es>
* otrsintern <otrsintern@gmail.com>
* s7design <otrs@s7designcreative.com>
* sergot <filip@sergot.pl>
* vlascoder <vlascoder@gmail.com>
* Úr Balázs <urbalazs@gmail.com>
